<?php 
$_['text_logo_brand'] = 'Đối tác';
?>