<?php
$_['text_write_by'] ='écrire à :';
$_['text_published_in'] ='Publié dans :';
$_['text_created_date'] ='Date de création :';
$_['text_hits'] ='Hits:';
$_['text_comment_count'] ='Commentaire :';
$_['text_readmore'] ='En savoir plus';
$_['text_leave_a_comment'] ='Laisser un commentaire';


 $_['ERROR_CAPTCHA'] ='le code Captcha n\'est pas correct';
 $_['error_email'] ='Le courriel n\'est pas correct';
 $_['error_comment'] ='Le courriel\'est pas correct';
 $_['error_user'] ='Nom complet n\'est pas correct';
 $_['text_in_related_by_tag'] ='blogs ayant les mêmes tags';
/**
 *
 */
 $_['text_children'] ='enfants';
 $_['text_in_same_category'] ='Même dans la catégorie';
 $_['text_list_comments'] ='Commentaires';
 $_['text_created'] ='Créé par';
 $_['text_postedby'] ='Posté par';
 $_['text_comment_link'] ='Commentaire Link';
 $_['nom_entrée'] ='Nom complet';
 $_['entry_email'] ='e-mail';
 $_['entry_comment'] ='Commentaire';
 $_['text_submit'] ='Soumettre';
 $_['text_tags'] ='Balises :';
 
 $_['text_like_this'] ='Like This :';
  $_['entry_captcha'] ='Captcha';
 /**
  *
  */
  $_['filter_blog_header_title'] ='Filtre Blogs par% s';
  $_['blogs_latest_header_title'] ='Les derniers blogs';

  /* blogcategory le module */
  // Position
$_['blog_category_heading_title'] ='Blog catégorie';

// Texte
$_['text_latest'] ='latest';
$_['text_mostviewed'] ='Les plus populaires';
$_['text_featured'] ='Sélection';
$_['text_bestseller'] ='best-seller';

/* module de blogcomment */
// Position
$_['blogcomment_heading_title'] ='Derniers commentaires';

$_['text_postedby'] ='Posté par';
/* bloglatest Module */
// Position
$_['bloglatest_heading_title'] ='latest';

// Texte
$_['text_latest'] ='Latest Blog';
$_['text_mostviewed'] ='Les plus populaires';
$_['text_featured'] ='Sélection';
$_['text_bestseller'] ='best-seller';
$_['entry_show_readmore'] ='Afficher Readmore';
$_['text_readmore'] ='En savoir plus';
?>