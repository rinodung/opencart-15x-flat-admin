<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']     = 'طرق الدفع';

// Text
$_['text_success']      = 'Success: You have modified payments!';
$_['text_list']         = 'Payment List';
$_['text_uninstall']    = 'ازالة التنصيب';

// Column
$_['column_name']       = 'طريقة الدفع';
$_['column_status']     = 'الحالة';
$_['column_sort_order'] = 'ترتيب الفرز';
$_['column_action']     = 'تحرير';

// Error
$_['error_permission']  = 'تحذير : أنت لا تمتلك صلاحيات التعديل!';
?>