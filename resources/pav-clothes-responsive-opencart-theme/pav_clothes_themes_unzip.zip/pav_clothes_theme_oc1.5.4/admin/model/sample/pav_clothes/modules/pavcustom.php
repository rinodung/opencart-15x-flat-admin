a:11:{i:1;a:8:{s:12:"module_title";a:3:{i:1;s:0:"";i:2;s:0:"";i:3;s:0:"";}s:11:"description";a:3:{i:1;s:228:"&lt;div class=&quot;adv-right&quot;&gt;&lt;a href=&quot;index.php?route=product/category&amp;amp;path=18&quot;&gt;&lt;img alt=&quot;Adv sitebar&quot; src=&quot;image/data/demo/adv-sitebar1.jpg&quot; /&gt;&lt;/a&gt;&lt;/div&gt;
";i:2;s:228:"&lt;div class=&quot;adv-right&quot;&gt;&lt;a href=&quot;index.php?route=product/category&amp;amp;path=18&quot;&gt;&lt;img alt=&quot;Adv sitebar&quot; src=&quot;image/data/demo/adv-sitebar1.jpg&quot; /&gt;&lt;/a&gt;&lt;/div&gt;
";i:3;s:228:"&lt;div class=&quot;adv-right&quot;&gt;&lt;a href=&quot;index.php?route=product/category&amp;amp;path=18&quot;&gt;&lt;img alt=&quot;Adv sitebar&quot; src=&quot;image/data/demo/adv-sitebar1.jpg&quot; /&gt;&lt;/a&gt;&lt;/div&gt;
";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:1:"2";s:8:"position";s:12:"column_right";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";s:1:"3";}i:2;a:8:{s:12:"module_title";a:3:{i:1;s:0:"";i:2;s:0:"";i:3;s:0:"";}s:11:"description";a:3:{i:1;s:229:"&lt;div class=&quot;adv-right&quot;&gt;&lt;a href=&quot;index.php?route=product/category&amp;amp;path=17&quot;&gt;&lt;img alt=&quot;Adv sitebar2&quot; src=&quot;image/data/demo/adv-sitebar2.jpg&quot; /&gt;&lt;/a&gt;&lt;/div&gt;
";i:2;s:229:"&lt;div class=&quot;adv-right&quot;&gt;&lt;a href=&quot;index.php?route=product/category&amp;amp;path=17&quot;&gt;&lt;img alt=&quot;Adv sitebar2&quot; src=&quot;image/data/demo/adv-sitebar2.jpg&quot; /&gt;&lt;/a&gt;&lt;/div&gt;
";i:3;s:229:"&lt;div class=&quot;adv-right&quot;&gt;&lt;a href=&quot;index.php?route=product/category&amp;amp;path=17&quot;&gt;&lt;img alt=&quot;Adv sitebar2&quot; src=&quot;image/data/demo/adv-sitebar2.jpg&quot; /&gt;&lt;/a&gt;&lt;/div&gt;
";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:1:"2";s:8:"position";s:12:"column_right";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";s:1:"4";}i:3;a:8:{s:12:"module_title";a:3:{i:1;s:0:"";i:2;s:0:"";i:3;s:0:"";}s:11:"description";a:3:{i:1;s:228:"&lt;div class=&quot;adv-right&quot;&gt;&lt;a href=&quot;index.php?route=product/category&amp;amp;path=18&quot;&gt;&lt;img alt=&quot;Adv sitebar&quot; src=&quot;image/data/demo/adv-sitebar1.jpg&quot; /&gt;&lt;/a&gt;&lt;/div&gt;
";i:2;s:228:"&lt;div class=&quot;adv-right&quot;&gt;&lt;a href=&quot;index.php?route=product/category&amp;amp;path=18&quot;&gt;&lt;img alt=&quot;Adv sitebar&quot; src=&quot;image/data/demo/adv-sitebar1.jpg&quot; /&gt;&lt;/a&gt;&lt;/div&gt;
";i:3;s:228:"&lt;div class=&quot;adv-right&quot;&gt;&lt;a href=&quot;index.php?route=product/category&amp;amp;path=18&quot;&gt;&lt;img alt=&quot;Adv sitebar&quot; src=&quot;image/data/demo/adv-sitebar1.jpg&quot; /&gt;&lt;/a&gt;&lt;/div&gt;
";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:1:"3";s:8:"position";s:12:"column_right";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";s:1:"3";}i:4;a:8:{s:12:"module_title";a:3:{i:1;s:0:"";i:2;s:0:"";i:3;s:0:"";}s:11:"description";a:3:{i:1;s:229:"&lt;div class=&quot;adv-right&quot;&gt;&lt;a href=&quot;index.php?route=product/category&amp;amp;path=17&quot;&gt;&lt;img alt=&quot;Adv sitebar2&quot; src=&quot;image/data/demo/adv-sitebar2.jpg&quot; /&gt;&lt;/a&gt;&lt;/div&gt;
";i:2;s:229:"&lt;div class=&quot;adv-right&quot;&gt;&lt;a href=&quot;index.php?route=product/category&amp;amp;path=17&quot;&gt;&lt;img alt=&quot;Adv sitebar2&quot; src=&quot;image/data/demo/adv-sitebar2.jpg&quot; /&gt;&lt;/a&gt;&lt;/div&gt;
";i:3;s:229:"&lt;div class=&quot;adv-right&quot;&gt;&lt;a href=&quot;index.php?route=product/category&amp;amp;path=17&quot;&gt;&lt;img alt=&quot;Adv sitebar2&quot; src=&quot;image/data/demo/adv-sitebar2.jpg&quot; /&gt;&lt;/a&gt;&lt;/div&gt;
";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:1:"3";s:8:"position";s:12:"column_right";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";s:1:"4";}i:5;a:8:{s:12:"module_title";a:3:{i:1;s:0:"";i:2;s:0:"";i:3;s:0:"";}s:11:"description";a:3:{i:1;s:740:"&lt;div class=&quot;welcome&quot;&gt;
&lt;div class=&quot;image&quot;&gt;&lt;img alt=&quot;Well come&quot; src=&quot;image/data/demo/welcome.png&quot; /&gt;&lt;/div&gt;

&lt;div class=&quot;web_block hidden-xs hidden-sm&quot;&gt;
&lt;h1&gt;Welcome !&lt;/h1&gt;

&lt;h2&gt;Duis sed odio sit amet nibh vulputate cursus a sit sociosqu ad litora&lt;/h2&gt;

&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla mi eros, facilisis ac mollis et, ullamcorper non neque. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed ac pretium dui. Praesent arcu dui, convallis eget facilisis in, vulputate ut lacus. Aliquam ultricies laoreet malesuada.&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
";i:2;s:740:"&lt;div class=&quot;welcome&quot;&gt;
&lt;div class=&quot;image&quot;&gt;&lt;img alt=&quot;Well come&quot; src=&quot;image/data/demo/welcome.png&quot; /&gt;&lt;/div&gt;

&lt;div class=&quot;web_block hidden-xs hidden-sm&quot;&gt;
&lt;h1&gt;Welcome !&lt;/h1&gt;

&lt;h2&gt;Duis sed odio sit amet nibh vulputate cursus a sit sociosqu ad litora&lt;/h2&gt;

&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla mi eros, facilisis ac mollis et, ullamcorper non neque. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed ac pretium dui. Praesent arcu dui, convallis eget facilisis in, vulputate ut lacus. Aliquam ultricies laoreet malesuada.&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
";i:3;s:740:"&lt;div class=&quot;welcome&quot;&gt;
&lt;div class=&quot;image&quot;&gt;&lt;img alt=&quot;Well come&quot; src=&quot;image/data/demo/welcome.png&quot; /&gt;&lt;/div&gt;

&lt;div class=&quot;web_block hidden-xs hidden-sm&quot;&gt;
&lt;h1&gt;Welcome !&lt;/h1&gt;

&lt;h2&gt;Duis sed odio sit amet nibh vulputate cursus a sit sociosqu ad litora&lt;/h2&gt;

&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla mi eros, facilisis ac mollis et, ullamcorper non neque. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed ac pretium dui. Praesent arcu dui, convallis eget facilisis in, vulputate ut lacus. Aliquam ultricies laoreet malesuada.&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:1:"1";s:8:"position";s:11:"content_top";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";s:1:"1";}i:6;a:8:{s:12:"module_title";a:3:{i:1;s:12:"Contact info";i:2;s:12:"Contact info";i:3;s:12:"Contact info";}s:11:"description";a:3:{i:1;s:508:"&lt;ul class=&quot;pav-contact-us clearfix&quot;&gt;
	&lt;li&gt;&lt;i class=&quot;icon fa fa-home&quot;&gt;&amp;nbsp;&lt;/i&gt;
	&lt;div class=&quot;l-text&quot;&gt;BrainOs Solution Company&lt;br /&gt;
	Limited&lt;/div&gt;
	&lt;/li&gt;
	&lt;li&gt;&lt;i class=&quot;icon fa fa-phone&quot;&gt;&amp;nbsp;&lt;/i&gt; + 084 123 678 999&lt;br /&gt;
	+ 084 987 123 654&lt;/li&gt;
	&lt;li&gt;&lt;i class=&quot;icon fa fa-envelope-o&quot;&gt;&amp;nbsp;&lt;/i&gt; Email: info@brainos.vn&lt;/li&gt;
&lt;/ul&gt;
";i:2;s:508:"&lt;ul class=&quot;pav-contact-us clearfix&quot;&gt;
	&lt;li&gt;&lt;i class=&quot;icon fa fa-home&quot;&gt;&amp;nbsp;&lt;/i&gt;
	&lt;div class=&quot;l-text&quot;&gt;BrainOs Solution Company&lt;br /&gt;
	Limited&lt;/div&gt;
	&lt;/li&gt;
	&lt;li&gt;&lt;i class=&quot;icon fa fa-phone&quot;&gt;&amp;nbsp;&lt;/i&gt; + 084 123 678 999&lt;br /&gt;
	+ 084 987 123 654&lt;/li&gt;
	&lt;li&gt;&lt;i class=&quot;icon fa fa-envelope-o&quot;&gt;&amp;nbsp;&lt;/i&gt; Email: info@brainos.vn&lt;/li&gt;
&lt;/ul&gt;
";i:3;s:508:"&lt;ul class=&quot;pav-contact-us clearfix&quot;&gt;
	&lt;li&gt;&lt;i class=&quot;icon fa fa-home&quot;&gt;&amp;nbsp;&lt;/i&gt;
	&lt;div class=&quot;l-text&quot;&gt;BrainOs Solution Company&lt;br /&gt;
	Limited&lt;/div&gt;
	&lt;/li&gt;
	&lt;li&gt;&lt;i class=&quot;icon fa fa-phone&quot;&gt;&amp;nbsp;&lt;/i&gt; + 084 123 678 999&lt;br /&gt;
	+ 084 987 123 654&lt;/li&gt;
	&lt;li&gt;&lt;i class=&quot;icon fa fa-envelope-o&quot;&gt;&amp;nbsp;&lt;/i&gt; Email: info@brainos.vn&lt;/li&gt;
&lt;/ul&gt;
";}s:10:"show_title";s:1:"1";s:9:"layout_id";s:5:"99999";s:8:"position";s:13:"footer_center";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";s:1:"1";}i:7;a:8:{s:12:"module_title";a:3:{i:1;s:6:"Brands";i:2;s:6:"Brands";i:3;s:6:"Brands";}s:11:"description";a:3:{i:1;s:1220:"&lt;div class=&quot;box&quot;&gt;
&lt;ul class=&quot;list&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/information&amp;amp;information_id=4&quot;&gt;About Us&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/information&amp;amp;information_id=6&quot;&gt;Delivery Information&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/information&amp;amp;information_id=3&quot;&gt;Privacy Policy&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/information&amp;amp;information_id=5&quot;&gt;Terms &amp;amp; Conditions&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/information&amp;amp;information_id=4&quot;&gt;Cum sociis&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/information&amp;amp;information_id=6&quot;&gt;Phasellus lacinia&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/information&amp;amp;information_id=3&quot;&gt;Donec massa&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/information&amp;amp;information_id=5&quot;&gt;Vivamus convallis&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
";i:2;s:1220:"&lt;div class=&quot;box&quot;&gt;
&lt;ul class=&quot;list&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/information&amp;amp;information_id=4&quot;&gt;About Us&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/information&amp;amp;information_id=6&quot;&gt;Delivery Information&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/information&amp;amp;information_id=3&quot;&gt;Privacy Policy&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/information&amp;amp;information_id=5&quot;&gt;Terms &amp;amp; Conditions&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/information&amp;amp;information_id=4&quot;&gt;Cum sociis&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/information&amp;amp;information_id=6&quot;&gt;Phasellus lacinia&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/information&amp;amp;information_id=3&quot;&gt;Donec massa&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/information&amp;amp;information_id=5&quot;&gt;Vivamus convallis&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
";i:3;s:1220:"&lt;div class=&quot;box&quot;&gt;
&lt;ul class=&quot;list&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/information&amp;amp;information_id=4&quot;&gt;About Us&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/information&amp;amp;information_id=6&quot;&gt;Delivery Information&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/information&amp;amp;information_id=3&quot;&gt;Privacy Policy&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/information&amp;amp;information_id=5&quot;&gt;Terms &amp;amp; Conditions&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/information&amp;amp;information_id=4&quot;&gt;Cum sociis&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/information&amp;amp;information_id=6&quot;&gt;Phasellus lacinia&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/information&amp;amp;information_id=3&quot;&gt;Donec massa&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/information&amp;amp;information_id=5&quot;&gt;Vivamus convallis&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
";}s:10:"show_title";s:1:"1";s:9:"layout_id";s:5:"99999";s:8:"position";s:13:"footer_center";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";s:1:"2";}i:8;a:8:{s:12:"module_title";a:3:{i:1;s:8:"Services";i:2;s:8:"Services";i:3;s:8:"Services";}s:11:"description";a:3:{i:1;s:921:"&lt;div class=&quot;box&quot;&gt;
&lt;ul class=&quot;list&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=product/manufacturer&quot;&gt;Brands&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/voucher&quot;&gt;Gift Vouchers&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=affiliate/account&quot;&gt;Affiliates&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=product/special&quot;&gt;Specials&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/account&quot;&gt;My Account&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/order&quot;&gt;Order History&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/wishlist&quot;&gt;Wish List&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/newsletter&quot;&gt;Newsletter&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
";i:2;s:921:"&lt;div class=&quot;box&quot;&gt;
&lt;ul class=&quot;list&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=product/manufacturer&quot;&gt;Brands&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/voucher&quot;&gt;Gift Vouchers&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=affiliate/account&quot;&gt;Affiliates&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=product/special&quot;&gt;Specials&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/account&quot;&gt;My Account&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/order&quot;&gt;Order History&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/wishlist&quot;&gt;Wish List&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/newsletter&quot;&gt;Newsletter&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
";i:3;s:921:"&lt;div class=&quot;box&quot;&gt;
&lt;ul class=&quot;list&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=product/manufacturer&quot;&gt;Brands&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/voucher&quot;&gt;Gift Vouchers&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=affiliate/account&quot;&gt;Affiliates&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=product/special&quot;&gt;Specials&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/account&quot;&gt;My Account&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/order&quot;&gt;Order History&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/wishlist&quot;&gt;Wish List&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/newsletter&quot;&gt;Newsletter&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
";}s:10:"show_title";s:1:"1";s:9:"layout_id";s:5:"99999";s:8:"position";s:13:"footer_center";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";s:1:"3";}i:9;a:8:{s:12:"module_title";a:3:{i:1;s:11:"Useful link";i:2;s:11:"Useful link";i:3;s:11:"Useful link";}s:11:"description";a:3:{i:1;s:949:"&lt;div class=&quot;box&quot;&gt;
&lt;ul class=&quot;list&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/contact&quot;&gt;Contact Us&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/return/insert&quot;&gt;Returns&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/sitemap&quot;&gt;Site Map&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/voucher&quot;&gt;Gift Vouchers&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/contact&quot;&gt;Suspendisse&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/return/insert&quot;&gt;Quisque lacinia&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/sitemap&quot;&gt;Cras libero&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/voucher&quot;&gt;Proin laoreet&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
";i:2;s:949:"&lt;div class=&quot;box&quot;&gt;
&lt;ul class=&quot;list&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/contact&quot;&gt;Contact Us&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/return/insert&quot;&gt;Returns&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/sitemap&quot;&gt;Site Map&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/voucher&quot;&gt;Gift Vouchers&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/contact&quot;&gt;Suspendisse&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/return/insert&quot;&gt;Quisque lacinia&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/sitemap&quot;&gt;Cras libero&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/voucher&quot;&gt;Proin laoreet&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
";i:3;s:949:"&lt;div class=&quot;box&quot;&gt;
&lt;ul class=&quot;list&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/contact&quot;&gt;Contact Us&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/return/insert&quot;&gt;Returns&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/sitemap&quot;&gt;Site Map&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/voucher&quot;&gt;Gift Vouchers&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/contact&quot;&gt;Suspendisse&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/return/insert&quot;&gt;Quisque lacinia&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/sitemap&quot;&gt;Cras libero&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/voucher&quot;&gt;Proin laoreet&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
";}s:10:"show_title";s:1:"1";s:9:"layout_id";s:5:"99999";s:8:"position";s:13:"footer_center";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";s:1:"4";}i:10;a:8:{s:12:"module_title";a:3:{i:1;s:12:"Subscribe us";i:2;s:12:"subscribe us";i:3;s:12:"Subscribe us";}s:11:"description";a:3:{i:1;s:1589:"&lt;div class=&quot;box &quot;&gt;
&lt;div class=&quot;newsletter-submit&quot;&gt;&lt;input alt=&quot;username&quot; class=&quot;inputbox&quot; name=&quot;email&quot; size=&quot;31&quot; type=&quot;text&quot; value=&quot;Type your email&quot; /&gt;&lt;input class=&quot;button&quot; name=&quot;Submit&quot; type=&quot;submit&quot; value=&quot;Sign up&quot; /&gt;&lt;/div&gt;

&lt;p&gt;Sunday when we are open from and dions contact page.&lt;/p&gt;
&lt;/div&gt;

&lt;div class=&quot;box&quot;&gt;
&lt;div class=&quot;box-heading&quot;&gt;Get social&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;social&quot;&gt;
&lt;ul&gt;
	&lt;li class=&quot;facebook&quot;&gt;&lt;a href=&quot;#&quot;&gt;&lt;i class=&quot;fa fa-facebook stack&quot;&gt;&lt;span&gt;Facebook&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li class=&quot;twitter&quot;&gt;&lt;a class=&quot;twitter&quot; href=&quot;#&quot;&gt;&lt;i class=&quot;fa fa-twitter stack&quot;&gt;&lt;span&gt;Twitter&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li class=&quot;google&quot;&gt;&lt;a href=&quot;#&quot;&gt;&lt;i class=&quot;fa fa-google-plus stack&quot;&gt;&lt;span&gt;Google Plus&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li class=&quot;youtube&quot;&gt;&lt;a href=&quot;#&quot;&gt;&lt;i class=&quot;fa fa-youtube stack&quot;&gt;&lt;span&gt;Youtube&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li class=&quot;pinterest&quot;&gt;&lt;a href=&quot;#&quot;&gt;&lt;i class=&quot;fa fa-pinterest stack&quot;&gt;&lt;span&gt;Printerest&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
";i:2;s:1589:"&lt;div class=&quot;box &quot;&gt;
&lt;div class=&quot;newsletter-submit&quot;&gt;&lt;input alt=&quot;username&quot; class=&quot;inputbox&quot; name=&quot;email&quot; size=&quot;31&quot; type=&quot;text&quot; value=&quot;Type your email&quot; /&gt;&lt;input class=&quot;button&quot; name=&quot;Submit&quot; type=&quot;submit&quot; value=&quot;Sign up&quot; /&gt;&lt;/div&gt;

&lt;p&gt;Sunday when we are open from and dions contact page.&lt;/p&gt;
&lt;/div&gt;

&lt;div class=&quot;box&quot;&gt;
&lt;div class=&quot;box-heading&quot;&gt;Get social&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;social&quot;&gt;
&lt;ul&gt;
	&lt;li class=&quot;facebook&quot;&gt;&lt;a href=&quot;#&quot;&gt;&lt;i class=&quot;fa fa-facebook stack&quot;&gt;&lt;span&gt;Facebook&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li class=&quot;twitter&quot;&gt;&lt;a class=&quot;twitter&quot; href=&quot;#&quot;&gt;&lt;i class=&quot;fa fa-twitter stack&quot;&gt;&lt;span&gt;Twitter&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li class=&quot;google&quot;&gt;&lt;a href=&quot;#&quot;&gt;&lt;i class=&quot;fa fa-google-plus stack&quot;&gt;&lt;span&gt;Google Plus&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li class=&quot;youtube&quot;&gt;&lt;a href=&quot;#&quot;&gt;&lt;i class=&quot;fa fa-youtube stack&quot;&gt;&lt;span&gt;Youtube&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li class=&quot;pinterest&quot;&gt;&lt;a href=&quot;#&quot;&gt;&lt;i class=&quot;fa fa-pinterest stack&quot;&gt;&lt;span&gt;Printerest&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
";i:3;s:1589:"&lt;div class=&quot;box &quot;&gt;
&lt;div class=&quot;newsletter-submit&quot;&gt;&lt;input alt=&quot;username&quot; class=&quot;inputbox&quot; name=&quot;email&quot; size=&quot;31&quot; type=&quot;text&quot; value=&quot;Type your email&quot; /&gt;&lt;input class=&quot;button&quot; name=&quot;Submit&quot; type=&quot;submit&quot; value=&quot;Sign up&quot; /&gt;&lt;/div&gt;

&lt;p&gt;Sunday when we are open from and dions contact page.&lt;/p&gt;
&lt;/div&gt;

&lt;div class=&quot;box&quot;&gt;
&lt;div class=&quot;box-heading&quot;&gt;Get social&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;social&quot;&gt;
&lt;ul&gt;
	&lt;li class=&quot;facebook&quot;&gt;&lt;a href=&quot;#&quot;&gt;&lt;i class=&quot;fa fa-facebook stack&quot;&gt;&lt;span&gt;Facebook&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li class=&quot;twitter&quot;&gt;&lt;a class=&quot;twitter&quot; href=&quot;#&quot;&gt;&lt;i class=&quot;fa fa-twitter stack&quot;&gt;&lt;span&gt;Twitter&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li class=&quot;google&quot;&gt;&lt;a href=&quot;#&quot;&gt;&lt;i class=&quot;fa fa-google-plus stack&quot;&gt;&lt;span&gt;Google Plus&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li class=&quot;youtube&quot;&gt;&lt;a href=&quot;#&quot;&gt;&lt;i class=&quot;fa fa-youtube stack&quot;&gt;&lt;span&gt;Youtube&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li class=&quot;pinterest&quot;&gt;&lt;a href=&quot;#&quot;&gt;&lt;i class=&quot;fa fa-pinterest stack&quot;&gt;&lt;span&gt;Printerest&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
";}s:10:"show_title";s:1:"1";s:9:"layout_id";s:5:"99999";s:8:"position";s:13:"footer_center";s:6:"status";s:1:"0";s:12:"module_class";s:0:"";s:10:"sort_order";i:5;}i:11;a:8:{s:12:"module_title";a:3:{i:1;s:0:"";i:2;s:0:"";i:3;s:0:"";}s:11:"description";a:3:{i:1;s:1586:"&lt;div class=&quot;pav-static&quot;&gt;
&lt;ul&gt;
	&lt;li class=&quot;col-xs-12 col-sm-6 col-lg-3 col-md-3&quot;&gt;
	&lt;p class=&quot;box-1&quot;&gt;&lt;span class=&quot;pv-icon pv-icon-feature&quot;&gt;Fearture&lt;/span&gt;&lt;/p&gt;

	&lt;div class=&quot;static-text&quot;&gt;
	&lt;h3 class=&quot;title-block&quot;&gt;Fearture&lt;/h3&gt;

	&lt;p&gt;Lorem ipsum dolor sit amet&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;col-xs-12 col-sm-6 col-lg-3 col-md-3&quot;&gt;
	&lt;p class=&quot;box-2&quot;&gt;&lt;span class=&quot;pv-icon pv-con-support&quot;&gt;Support&lt;/span&gt;&lt;/p&gt;

	&lt;div class=&quot;static-text&quot;&gt;
	&lt;h3 class=&quot;title-block&quot;&gt;Support&lt;/h3&gt;

	&lt;p&gt;Lorem ipsum dolor sit amet&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;col-xs-12 col-sm-6 col-lg-3 col-md-3&quot;&gt;
	&lt;p class=&quot;box-3&quot;&gt;&lt;span class=&quot;pv-icon pv-con-shipping&quot;&gt;Shipping&lt;/span&gt;&lt;/p&gt;

	&lt;div class=&quot;static-text&quot;&gt;
	&lt;h3 class=&quot;title-block&quot;&gt;Free shipping&lt;/h3&gt;

	&lt;p&gt;Lorem ipsum dolor sit amet&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;col-xs-12 col-sm-6 col-lg-3 col-md-3&quot;&gt;
	&lt;p class=&quot;box-4&quot;&gt;&lt;span class=&quot;pv-icon pv-con-mauris&quot;&gt;Mauris&lt;/span&gt;&lt;/p&gt;

	&lt;div class=&quot;static-text&quot;&gt;
	&lt;h3 class=&quot;title-block&quot;&gt;Mauris nisi&lt;/h3&gt;

	&lt;p&gt;Lorem ipsum dolor sit amet&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
";i:2;s:1586:"&lt;div class=&quot;pav-static&quot;&gt;
&lt;ul&gt;
	&lt;li class=&quot;col-xs-12 col-sm-6 col-lg-3 col-md-3&quot;&gt;
	&lt;p class=&quot;box-1&quot;&gt;&lt;span class=&quot;pv-icon pv-icon-feature&quot;&gt;Fearture&lt;/span&gt;&lt;/p&gt;

	&lt;div class=&quot;static-text&quot;&gt;
	&lt;h3 class=&quot;title-block&quot;&gt;Fearture&lt;/h3&gt;

	&lt;p&gt;Lorem ipsum dolor sit amet&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;col-xs-12 col-sm-6 col-lg-3 col-md-3&quot;&gt;
	&lt;p class=&quot;box-2&quot;&gt;&lt;span class=&quot;pv-icon pv-con-support&quot;&gt;Support&lt;/span&gt;&lt;/p&gt;

	&lt;div class=&quot;static-text&quot;&gt;
	&lt;h3 class=&quot;title-block&quot;&gt;Support&lt;/h3&gt;

	&lt;p&gt;Lorem ipsum dolor sit amet&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;col-xs-12 col-sm-6 col-lg-3 col-md-3&quot;&gt;
	&lt;p class=&quot;box-3&quot;&gt;&lt;span class=&quot;pv-icon pv-con-shipping&quot;&gt;Shipping&lt;/span&gt;&lt;/p&gt;

	&lt;div class=&quot;static-text&quot;&gt;
	&lt;h3 class=&quot;title-block&quot;&gt;Free shipping&lt;/h3&gt;

	&lt;p&gt;Lorem ipsum dolor sit amet&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;col-xs-12 col-sm-6 col-lg-3 col-md-3&quot;&gt;
	&lt;p class=&quot;box-4&quot;&gt;&lt;span class=&quot;pv-icon pv-con-mauris&quot;&gt;Mauris&lt;/span&gt;&lt;/p&gt;

	&lt;div class=&quot;static-text&quot;&gt;
	&lt;h3 class=&quot;title-block&quot;&gt;Mauris nisi&lt;/h3&gt;

	&lt;p&gt;Lorem ipsum dolor sit amet&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
";i:3;s:1586:"&lt;div class=&quot;pav-static&quot;&gt;
&lt;ul&gt;
	&lt;li class=&quot;col-xs-12 col-sm-6 col-lg-3 col-md-3&quot;&gt;
	&lt;p class=&quot;box-1&quot;&gt;&lt;span class=&quot;pv-icon pv-icon-feature&quot;&gt;Fearture&lt;/span&gt;&lt;/p&gt;

	&lt;div class=&quot;static-text&quot;&gt;
	&lt;h3 class=&quot;title-block&quot;&gt;Fearture&lt;/h3&gt;

	&lt;p&gt;Lorem ipsum dolor sit amet&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;col-xs-12 col-sm-6 col-lg-3 col-md-3&quot;&gt;
	&lt;p class=&quot;box-2&quot;&gt;&lt;span class=&quot;pv-icon pv-con-support&quot;&gt;Support&lt;/span&gt;&lt;/p&gt;

	&lt;div class=&quot;static-text&quot;&gt;
	&lt;h3 class=&quot;title-block&quot;&gt;Support&lt;/h3&gt;

	&lt;p&gt;Lorem ipsum dolor sit amet&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;col-xs-12 col-sm-6 col-lg-3 col-md-3&quot;&gt;
	&lt;p class=&quot;box-3&quot;&gt;&lt;span class=&quot;pv-icon pv-con-shipping&quot;&gt;Shipping&lt;/span&gt;&lt;/p&gt;

	&lt;div class=&quot;static-text&quot;&gt;
	&lt;h3 class=&quot;title-block&quot;&gt;Free shipping&lt;/h3&gt;

	&lt;p&gt;Lorem ipsum dolor sit amet&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;col-xs-12 col-sm-6 col-lg-3 col-md-3&quot;&gt;
	&lt;p class=&quot;box-4&quot;&gt;&lt;span class=&quot;pv-icon pv-con-mauris&quot;&gt;Mauris&lt;/span&gt;&lt;/p&gt;

	&lt;div class=&quot;static-text&quot;&gt;
	&lt;h3 class=&quot;title-block&quot;&gt;Mauris nisi&lt;/h3&gt;

	&lt;p&gt;Lorem ipsum dolor sit amet&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
";}s:10:"show_title";s:1:"1";s:9:"layout_id";s:5:"99999";s:8:"position";s:10:"footer_top";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";s:0:"";}}