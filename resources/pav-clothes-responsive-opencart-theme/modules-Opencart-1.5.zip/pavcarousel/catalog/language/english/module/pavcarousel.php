<?php 
$_['text_logo_brand'] = 'Top Brand';
?>