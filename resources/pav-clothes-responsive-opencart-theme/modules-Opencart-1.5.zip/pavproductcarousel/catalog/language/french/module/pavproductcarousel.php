<?php
// Heading 
$_['heading_title'] = 'Dernier';

// Text
$_['text_latest']  = 'Dernier'; 
$_['text_mostviewed']  = 'Les Plus Vues'; 
$_['text_featured']  = 'Featured'; 
$_['text_bestseller']  = 'Mieux Vendeur'; 
$_['text_special']  = 'Spécial'; 

$_['text_sale'] = 'Vente';
$_['text_sale_detail'] = 'Sauver: %s';
?>
