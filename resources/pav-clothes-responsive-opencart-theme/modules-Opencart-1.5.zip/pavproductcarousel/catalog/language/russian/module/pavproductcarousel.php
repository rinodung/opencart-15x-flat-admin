<?php
// Heading 
$_['heading_title'] = 'последний';

// Text
$_['text_latest']  = 'последний'; 
$_['text_mostviewed'] = 'Самые популярные';
$_['text_featured'] = 'Лучшее';
$_['text_bestseller'] = 'Бестселлер';
$_['text_special'] = 'Специальные';

$_['text_sale'] = 'продажа';
$_['text_sale_detail'] = 'Сохранить:%s';
?>
